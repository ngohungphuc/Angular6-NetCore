﻿import { Component } from '@angular/core';

@Component({
    selector: 'my-app',
    templateUrl: 'partial/app'
})
export class AppComponent {
    welcomeMsg = 'Welcome to Angular4 & ASP.Net Core'
}